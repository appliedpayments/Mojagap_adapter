import { Server, Socket } from 'net'
//import Knex from 'knex'
import { Worker, Job, ConnectionOptions } from 'bullmq'
import { raw } from 'objection'
import { QueueService } from '../services/queue-service'
import { Logger } from '../adaptor'
import { LegacyAuthorizationRequest, LegacyAuthorizationResponse, LegacyFinancialRequest, LegacyFinancialResponse, LegacyReversalRequest, ResponseType, LegacyReversalResponse } from '../types/adaptor-relay-messages'
import { LpsMessage, LegacyMessageType } from '../models'
import { Money } from '@mojaloop/sdk-standard-components'
import { HOST ,databasefile,quotesEndpoint,TransfersEndpoint , otpEndpoint , otpendpoint , checkParticipantEndpoint,database,spacing,url,log,url_autorization,url_20022,url_mpesa,url_openapi} from '../utils/constants'
import { TcpRelay, LegacyMessage } from '../types/tcpRelay'
import { ResponseCodes, TcpRelayServices, TcpRelayConfig } from '../types/tcpRelay'
import { stringify } from 'querystring';
import{fs,request,js2xmlparser,MlNumber,IsoParser,xmlParser,parser,pads,fetch,bcd,iso8583} from '../utils/imports'
let  flag = ''



export class BaseTcpRelay implements TcpRelay {

  protected _logger: Logger
  protected _queueService: QueueService
  protected _lpsId: string
  protected _transactionExpiryWindow: number
  protected _redisConnection: ConnectionOptions
  protected _server?: Server
  protected _socket: Socket
  //protected _knex: Knex

  protected _encode: (message: { [k: string]: any }) => Buffer
  protected _decode: (message: Buffer) => { [k: string]: any }

  protected _authorizationResponseWorker?: Worker
  protected _financialResponseWorker?: Worker
  protected _reversalResponseWorker?: Worker
  protected _responseCodes: ResponseCodes
  

  constructor ({ logger, queueService, encode, decode, socket}: TcpRelayServices, { lpsId, transactionExpiryWindow, redisConnection, responseCodes }: TcpRelayConfig) {
    if (!socket) {
      throw new Error(`${lpsId} relay: Cannot be created as there is no socket registered.`)
    }
    this._socket = socket
    this._logger = logger
    this._queueService = queueService
    this._encode = encode
    this._decode = decode
    this._lpsId = lpsId
    var table = ''
    

    /*this._knex  = 'mysql' ? Knex({
      client: 'mysql',
      connection: {
        host:'localhost',
        user: 'root',
        password:'root',
        database: 'testing'
      }
    }) : Knex({
      client: 'sqlite3',
      connection: {
        filename: ':memory:',
        supportBigNumbers: true
      },
      useNullAsDefault: true
    })*/
     
    /*var stats = fs.statSync(databasefile)
    if(stats["size"]== 0)  {
      for (var i = 0; i < database.length ; i++) 
       table = table + pads(database[i],spacing[i],' ');

      log.info(table);
      this._knex.from('transactiontable').select("*")
      .then((rows) => {
        rows.forEach (isoMessage => {
            table = ''
            for (var i = 0; i < database.length ; i++) 
              table = table + pads(`${isoMessage[`${database[i]}`]}`,spacing[i],' ');
            log.info(table)
            }
       )}).catch((err) => { console.log( err); throw err })
      }*/

    this._transactionExpiryWindow = transactionExpiryWindow || 30
    this._redisConnection = redisConnection ?? { host: 'localhost', port: 6379 }
    this._responseCodes = responseCodes ?? { approved: '00', invalidTransaction: 'N0', noAction: '21', doNotHonour: '05', noIssuer: '15' }

    socket.on('data', async (data) => {
      try {
        this._logger.debug(`${this._lpsId} relay: Received buffer message`)
       //console.log('data',data)
        const mti = data.slice(2, 6).toString() 
        var  legacyMessage1 = this._decode(data)
        flag = mti
       // const mti = legacyMessage1[0]
        if(mti == '0200'&& legacyMessage1[3] !='010000' && legacyMessage1[3] !='000000'  ){

          const legacyMessage = this._decode(data) 
          var lpsKey = null
          var messageType = null
          let format = 'MPESA'
          legacyMessage[0] = mti
          lpsKey = this.getLpsKey(legacyMessage)

          if(legacyMessage[0] != '0421'){
            this._logger.debug(this._lpsId + ' relay: Received message from: ' + this._lpsId + ' lpsKey: ' + lpsKey)
            this._logger.debug(this._lpsId + ' relay: Message converted to JSON: ' + JSON.stringify(legacyMessage))
          }
  
          messageType = this.getMessageType(legacyMessage[0])
          const processingcode = legacyMessage[3].toString().substring(0,2)
          const  url2 = url_autorization+legacyMessage[102]

          console.log('fetching user login details for ',legacyMessage[102])

          await  fetch(url2, {
              headers: {
                  'Accept': 'application/json',
              },
              method: "POST",

          })
          .then((response:any) => response.text())    
          .then((text:any) => {
            const data = JSON.parse(text);
            format = data['response']['format']
            if(!data['response']['format'])
              format = 'user_not_registered'
        
          });    
  
        var json_withdrawal_request  = {}

        switch(format){

          case 'MPESA':

          console.log('isomessage recieved :', legacyMessage)
          var buf = Buffer.from(data);
          json_withdrawal_request = {
              "input_Username": "test_user",
              "input_Password": legacyMessage[103],
              "input_CustomerMSISDN": legacyMessage[102],
              "input_Currency": legacyMessage[49],
              "input_BankShortcode": legacyMessage[2].slice(0,6),
              "input_Amount": legacyMessage[4],
              "input_ThirdPartyReference": "71c6d1f93910052de053",
              "input_BankTransactionRef": "12345678123412341234123456789abc"
          }
          const  url2 = url_autorization+legacyMessage[102]
          console.log('fetching user login details for ',legacyMessage[102])
          await  fetch(url2, {
              headers: {
                  'Accept': 'application/json',
              },
              method: "POST",

          })
          .then((response:any) => response.text())
          .then((text:any) => {
            const data = JSON.parse(text);
            console.log('Response recieved from loginuser', data)
          
            json_withdrawal_request = {
              "status":data['status'],
              "input_Username": data['response']['username'],
              "input_Password":data['response']['password'],
              "input_CustomerMSISDN":data['response']['msisdn'],
              "input_Currency":data['response']['currencycode'],
              "input_BankShortcode": legacyMessage[2].slice(0,6),
              "input_Amount": legacyMessage[4],
              "input_ThirdPartyReference": "71c6d1f93910052de053",
              "input_BankTransactionRef": "12345678123412341234123456789abc"
            }
            console.log('Request to m-pesa : ', json_withdrawal_request)
          });
          console.log('Sending to m-pesa : ', url_mpesa)
          let conversion_to = 'mpesa';
         /* const result = await this._knex('transactiontable').insert({
            msisdn:legacyMessage[102],
            amount:legacyMessage[4],
            currencycode:legacyMessage[49],
            incoming_format:'legacy[0]',
            conversion_to,
            input_BankShortcode: 'legacyMessage[2].slice(0,6)',
            input_ThirdPartyReference: "71c6d1f93910052de053",
            success:'pending',
            reversed: 'pending'
         }).then(result => result[0])

         console.log('After db insert : ', url)
        const isoMessage = await this._knex('transactiontable').where({ id: result }).first()*/
         
          await fetch(url_mpesa, {
                    headers: {
                        'Accept': 'application/json',
                    },
                    method: "POST",
                    body: JSON.stringify(json_withdrawal_request)
          }).then((response:any) => response.text())
            .then((text:any) => {
                try {
                    const data = JSON.parse(text);

                    console.log('Response recieved from m-pesa:', data)
                    if (data['output_ResponseCode'] == '0') {

                        console.log("Transaction result:", data['output_ResponseDesc'])
                        socket.write(encode({ ...legacyMessage, 0: '0210', 39: '00' }))
                        
                        legacyMessage[0]= '0210'
                        legacyMessage[39]= '00'

                        console.log('Resposne:', legacyMessage)
                    } else if (data['output_ResponseCode'] == '-1') {

                        console.log("Transaction result:", data['output_ResponseDesc'])
                        console.log("User msisdn is not registered...")
                       socket.write(encode({ ...legacyMessage, 0: '0210', 39: '12' }))

                       legacyMessage[0]= '0210'
                       legacyMessage[39]= '12'

                        console.log('Resposne:', legacyMessage)
                    } else if (data['output_ResponseCode'] == '-3') {

                        console.log("Transaction result:", data['output_ResponseDesc'])
                        socket.write(encode({ ...legacyMessage, 0: '0210', 39: '54' }))

                        legacyMessage[0]= '0210'
                        legacyMessage[39]= '54'

                        console.log('Resposne:', legacyMessage)
                    }
                } catch (error) {
                    //this._logger.error(error)
                }
            });

           /* if(legacyMessage[39]=='00'){

              const query = await this._knex('transactiontable').where({id: result}).first().update('reversed', '01').update('success',legacyMessage[39])
              const isoMessage = await this._knex('transactiontable').where({ id: result }).first()
              table = ''
              for (var i = 0; i < database.length ; i++) 
                table = table + pads(`${isoMessage[`${database[i]}`]}`,spacing[i],' ');

              log.info(table)
              console.log('Reflected in database')
            }else{
              const query = await this._knex('transactiontable').where({id: result}).first().update('reversed', '01').update('success',legacyMessage[39])
              const isoMessage = await this._knex('transactiontable').where({ id: result }).first()
              table = ''
              for (var i = 0; i < database.length ; i++) 
                table = table + pads(`${isoMessage[`${database[i]}`]}`,spacing[i],' ');
                
              log.info(table)
            }*/
          break;
          case '20022XML':  
            console.log('isomessage recieved :', legacyMessage)
            var iso20022 = {
              "xmlns": "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.05",
              "xsi": "http://www.w3.org/2001/XMLSchema-instance",
              "FIToFICstmrCdtTrf": {
                "GrpHdr": {
                    "MsgId": "7c23e80c-d078-4077-8263-2c047876fcf6",
                    "CreDtTm": new Date(new Date().getTime() + 10000),
                    "NbOfTxs": "1",
                    "SttlmInf": {
                        "SttlmMtd": "CLRG"
                    }
                },
                "CdtTrfTxInf": {
                    "PmtId": {
                        "EndToEndId": "KGB57799",
                        "TxId": "KGB57799"
                    },
                    "PmtTpInf": {
                        "SvcLvl": {
                            "Cd": "NURG"
    
                        }
                    },
                    "IntrBkSttlmAmt": {
                        "Ccy": legacyMessage[49],
                        "amount": legacyMessage[4]
                    },
                    "IntrBkSttlmDt": "2020-01-01",
                    "ChrgBr": "SLEV",
                    "Dbtr": {
                        "Nm": "Joe Soap",
                        "PstlAdr": {
                            "PstlAdr": {
                                "StrtNm": "120 HIGH ROAD",
                                "PstCd": "4430",
                                "TwnNm": "Manzini",
                                "Ctry": "SZ"
                            }
                        }
    
                    },
                    "DbtrAcct": {
                        "Id": {
                            "other": {
                                "Id": legacyMessage[102]
                            }
                        }
                    },
                    "DbtrAgt": {
                        "FinInstnId": {
                            "BICFI": legacyMessage[32]
                        }
                    },
                    "CdtrAgt": {
                        "FinInstnId": {
                            "BICFI": legacyMessage[100]
                        }
    
                    },
                    "Cdtr": {
                        "Nm": "SOAP",
                        "PstlAdr": {
                            "StrtNm": "78 Strand Str",
                            "PstCd": "6725",
                            "TwnNm": "Cape Town",
                            "Ctry": "ZA"
                        }
    
                    },
                    "CdtrAcct": {
                        "Id": {
                            "Other": {
                                "Id": legacyMessage[103]
                            }
                        }
    
                    },
                    "RgltryRptg": {
                        "Dtls": {
                            "Cd": "10402"
                        }
    
                    },
                    "RmtInf": {
                        "Ustrd": "52363"
                    }
                }
    
            }
        }
        this._logger.info("Converting iso0200 to iso20022 xml format:")

        console.log(js2xmlparser.parse("Document", iso20022));

      /*  const result1 = await this._knex('transactiontable').insert({
          msisdn:legacyMessage[102],
          amount:legacyMessage[4],
          currencycode:legacyMessage[49],
          incoming_format:'legac[0]',
          conversion_to:format,
          input_BankShortcode: 'legacyMessage[2].slice(0,6)',
          input_ThirdPartyReference: "71c6d1f93910052de053",
          success:'pending',
          reversed: 'pending'
       }).then(result => result[0])
        const isoMessage1 = await this._knex('transactiontable').where({ id: result1 }).first()*/
        try{
      
        const response = await fetch(url_20022, {
          headers: {
              Accept: 'text/xml'
          },
          method: "POST",
          body: js2xmlparser.parse("Document", iso20022)
      }).then((response:any) => response.text())
        .then((text:any) => {
          this._logger.info('Sending to :'+url_20022)
          this._logger.info("Response for 20022:")  
          console.log( text)
         let result = xmlParser.xml2json(text, { compact: true, spaces: 4 });
        var objectValue = JSON.parse(result);

        if(objectValue['response']['code']['_text']=='3000'){

          socket.write(encode({ ...legacyMessage, 0: '0210', 39: '00' }))
          this._logger.info('Sending reponse:')
          legacyMessage[0]= '0210'
          legacyMessage[39]='00'

          console.log(legacyMessage)
          

        }else{

          legacyMessage[39]='91'
          socket.write(encode({ ...legacyMessage, 0: '0210', 39: '91' }))
          this._logger.info('Sending reponse: ')
          legacyMessage[0]= '0210'
          legacyMessage[39]='91'

          console.log(legacyMessage)
        }
       
        });

       /* const query = await this._knex('transactiontable').where({id: result1}).first().update('reversed', '01').update('success',legacyMessage[39])
        const isoMessage = await this._knex('transactiontable').where({ id: result1 }).first()
        table = ''
        for (var i = 0; i < database.length ; i++) 
          table = table + pads(`${isoMessage[`${database[i]}`]}`,spacing[i],' ');

        log.info(table)
        console.log('Reflected in database')*/

      }catch(error){
        this._logger.error(error)
      }
          break;
          case 'OPENAPI':
          console.log('isomessage recieved :', legacyMessage)
         /* const result2 = await this._knex('transactiontable').insert({
            msisdn:legacyMessage[102],
            amount:legacyMessage[4],
            currencycode:legacyMessage[49],
            incoming_format:'lega[0]',
            conversion_to:format,
            input_BankShortcode: 'legacyMessage[2].slice(0,6)',
            input_ThirdPartyReference: "71c6d1f93910052de053",
            success:'pending',
            reversed: 'pending'
         }).then(result => result[0])
          const isoMessage2 = await this._knex('transactiontable').where({ id: result2}).first()*/
          const transaction_request = {
            transactionId: '7c23e80c-d078-4077-8263-2c047876fcf6',
            payee: {
              partyIdInfo: {
                partyIdType: 'IBAN',
                partyIdentifier:legacyMessage[2].slice(0,6),
                fspId: 'payerfsp'
              }
            },
            payer: {
              personalInfo: {
                complexName: {
                  firstName: legacyMessage[102],
                  lastName: 'Hagman'
                }
              },
              partyIdInfo: {
                partyIdType: 'MSISDN',
                partyIdentifier: legacyMessage[102],
                fspId: 'M-Pesa'
              }
            },
            amountType: 'RECEIVE',
            surcharge: '',
            amount: {
              amount: legacyMessage[4],
              currency: legacyMessage[49]
            },
            transactionType: {
              scenario: 'TRANSFER',
              initiator: 'PAYER',
              initiatorType: 'CONSUMER'
            },
            note: 'From Mats',
            expiration: new Date(new Date().getTime() + 10000)
          }
          var  url1 = url
          console.log('Converting to Open-api Request : ',)
          console.log()
          console.log( transaction_request)
          console.log('Sending to ',url_openapi)
          let resultmpesa = await fetch(url_openapi, {
                  headers: {
                      'Accept': 'application/json',
                  },
                  method: "POST",
                  body: JSON.stringify(transaction_request)
          }) .then((response: any) => response.text())
          .then((text: any) => {
              try {
                const data = JSON.parse(text);
                  console.log('Response received : 200')

                  socket.write(encode({ ...legacyMessage, 0: '0210', 39: '00' }))
                  this._logger.info('Sending reponse:')
                  legacyMessage[0]= '0210'
                  legacyMessage[39]='00'
        
                  console.log(legacyMessage)
                  
                  socket.write(Buffer.from('200 ok'))
                  }
                catch (error) {
                  //this._logger.error(error)
              }
          })
         /* const query = await this._knex('transactiontable').where({id: result2}).first().update('reversed', '01').update('success','00')
          const isoMessage3 = await this._knex('transactiontable').where({ id: result2 }).first()
          table = ''
          for (var i = 0; i < database.length ; i++) 
            table = table + pads(`${isoMessage3[`${database[i]}`]}`,spacing[i],' ');
            
            log.info(table)
          console.log('Reflected in database')*/
        
          break;
          case 'user_not_registered':

          console.log('user_not_registered')

          legacyMessage[39]='91'
          socket.write(encode({ ...legacyMessage, 0: '0210', 39: '91' }))
          this._logger.info('Sending reponse: ')
          legacyMessage[0]= '0210'
          legacyMessage[39]='91'

          console.log(legacyMessage)
          break;
        }
        if(mti == '0200'){
        const lpsMessage = await LpsMessage.query().insertAndFetch({ lpsId: this._lpsId, lpsKey, type: messageType, content: legacyMessage })
        switch (messageType) {
          case LegacyMessageType.authorizationRequest:
            this._queueService.addToQueue('LegacyAuthorizationRequests', await this.mapFromAuthorizationRequest(lpsMessage.id, legacyMessage))
            break
          case LegacyMessageType.financialRequest:
           // this._queueService.addToQueue('LegacyFinancialRequests', await this.mapFromFinancialRequest(lpsMessage.id, legacyMessage))
            break
          case LegacyMessageType.reversalRequest:
            try {
              this._queueService.addToQueue('LegacyReversalRequests', await this.mapFromReversalAdvice(lpsMessage.id, legacyMessage))
            } catch (error) {
              this._logger.error(this._lpsId + ' relay: Could not process the reversal request from: ' + this._lpsId + ' lpsKey: ' + lpsKey)
              socket.write(encode({ ...legacyMessage, 0: '0430', 39: '21' }))
            }
            break
            case null:
            break
          default:
            this._logger.error(`${this._lpsId} relay: Cannot handle legacy message with mti: ${legacyMessage[0]}`)
        }
      }
        }else if(mti == 'mpes'){

          console.log('Data Received :', data.toString())
          const jsondata = JSON.parse(data.toString())
    
          console.log('M-PesaJSON :',jsondata)
        /*  const result = await this._knex('transactiontable').insert({
            msisdn:jsondata['input_CustomerMSISDN'],
            amount:jsondata['input_Amount'],
            currencycode:jsondata['input_Currency'],
            incoming_format:jsondata['mpes'],
            conversion_to:'openapiformat',
            input_BankShortcode: jsondata['input_BankShortcode'],
            input_ThirdPartyReference: jsondata['input_ThirdPartyReference'],
            success:'pending',
            reversed:'01'
         }).then(result => result[0])
  
          const isoMessage = await this._knex('transactiontable').where({ id: result }).first()*/
    
          const transaction_request = {
            transactionId: '7c23e80c-d078-4077-8263-2c047876fcf6',
            payee: {
              partyIdInfo: {
                partyIdType: 'IBAN',
                partyIdentifier:jsondata['input_BankShortcode'] ,
                fspId: 'payerfsp'
              }
            },
            payer: {
              personalInfo: {
                complexName: {
                  firstName: jsondata['TestIsoMessage.java'],
                  lastName: 'Hagman'
                }
              },
              partyIdInfo: {
                partyIdType: 'MSISDN',
                partyIdentifier: jsondata['input_CustomerMSISDN'],
                fspId: 'M-Pesa'
              }
            },
            amountType: 'RECEIVE',
            surcharge: '',
            amount: {
              amount: jsondata['input_Amount'],
              currency: jsondata['input_Currency']
            },
            transactionType: {
              scenario: 'TRANSFER',
              initiator: 'PAYER',
              initiatorType: 'CONSUMER'
            },
            note: 'From Mats',
            expiration: new Date(new Date().getTime() + 10000)
          }
          var  url1 = url
          console.log('Converting to Open-api Request : ',)
          console.log()
          console.log( transaction_request)
          console.log('Sending to ',url1)
          let resultmpesa = await fetch(url1, {
                  headers: {
                      'Accept': 'application/json',
                  },
                  method: "POST",
                  body: JSON.stringify(transaction_request)
          }) .then((response: any) => response.text())
          .then((text: any) => {
              try {
                const data = JSON.parse(text);
                  console.log('Response received : 200')
                  
                  socket.write(Buffer.from('200 ok'))
                  }
                catch (error) {
                  //this._logger.error(error)
              }
          })
         /* const query = await this._knex('transactiontable').where({id: result}).first().update('reversed', '01').update('success','00')
          const isoMessage1 = await this._knex('transactiontable').where({ id: result }).first()
          table = ''
          for (var i = 0; i < database.length ; i++) 
            table = table + pads(`${isoMessage1[`${database[i]}`]}`,spacing[i],' ');
            
            log.info(table)
          console.log('Reflected in database')*/
         
        }else if(mti == 'xml '){
          //****************************************************************************** */
         // console.log('inside xml')
       // let result = xmlParser.xml2json(data.toString(), { compact: true, spaces: 4 });
          
         
       // console.log("Recieved 20022xmldata:", result);
      
      //  console.log("Recieved 20022xmldata:",js2xmlparser.parse("Document", data));
       console.log(data.toString())
       //let result = xmlParser.xml2json(data.toString());
    
       // var objectValue = JSON.parse(result);
        //console.log('objectvalue',objectValue)
        let transaction_id = 'KGB57799'//objectValue.elements[0]['elements'][2]['elements'][1]['elements'][0]['elements'][1]['elements'][0]['text']
        let accountnumber = '123456789'//objectValue.elements[0]['elements'][2]['elements'][1]['elements'][10]['elements'][0]['elements'][0]['elements'][0]['elements'][0]['text']
        let customerMSDISDN ='+263-7788050533'//objectValue.elements[0]['elements'][2]['elements'][1]['elements'][9]['elements'][2]['elements'][0]['elements'][0]['text']
        let amount = '000000100000'//objectValue.elements[0]['elements'][2]['elements'][1]['elements'][2]['elements'][1]['elements'][0]['text']
        //console.log(objectValue.elements[0]['elements'][2]['elements'][1]['elements'])
  
   // let transaction_id = objectValue['Document']['FIToFICstmrCdtTrf']['CdtTrfTxInf']['PmtId']['TxId']['_text'];
      // let accountnumber = '1234'//objectValue['Document']['FIToFICstmrCdtTrf']['CdtTrfTxInf']['CdtrAcct']['Id']['Other']['Id']['_text'];
       // let customerMSDISDN ='1234' //objectValue['Document']['FIToFICstmrCdtTrf']['CdtTrfTxInf']['Cdtr']['CtctDtls']['MobNb']['_text'];
   // let amount = '1234'//objectValue['Document']['FIToFICstmrCdtTrf']['CdtTrfTxInf']['IntrBkSttlmAmt']['amount']['_text'];
        let currency_code ='840' //objectValue['Document']['FIToFICstmrCdtTrf']['CdtTrfTxInf']['IntrBkSttlmAmt']['Ccy']['_text']
         json_withdrawal_request = {
            "input_AccountNumber": accountnumber,
            "input_CustomerMSISDN": customerMSDISDN,
            "input_Amount": amount,
            "input_Currency": currency_code,
            "input_TransactionID": transaction_id
        }  

        /* result = await this._knex('transactiontable').insert({
          msisdn:customerMSDISDN,
          amount:amount,
          currencycode:currency_code,
          incoming_format:'20022xml',
          conversion_to:'openapi',
          input_BankShortcode: accountnumber,
          input_ThirdPartyReference: transaction_id,
          success:'pending',
          reversed:'01'
       }).then(result => result[0])

        const isoMessage = await this._knex('transactiontable').where({ id: result }).first()*/

        const transaction_request = {
          transactionId: '7c23e80c-d078-4077-8263-2c047876fcf6',
          payee: {
            partyIdInfo: {
              partyIdType: 'IBAN',
              partyIdentifier:transaction_id ,
              fspId: 'payerfsp'
            }
          },
          payer: {
            personalInfo: {
              complexName: {
                firstName: accountnumber,
                lastName: ''
              }
            },
            partyIdInfo: {
              partyIdType: 'MSISDN',
              partyIdentifier: customerMSDISDN,
              fspId: 'M-Pesa'
            }
          },
          amountType: 'RECEIVE',
          surcharge: '',
          amount: {
            amount:  amount,
            currency: currency_code
          },
          transactionType: {
            scenario: 'TRANSFER',
            initiator: 'PAYER',
            initiatorType: 'CONSUMER'
          },
          note: '',
          expiration: new Date(new Date().getTime() + 10000)
        }
        //console.log('Converting to Open-api Request : ',)
        //console.log()
        //console.log( transaction_request)
        //console.log('Sending to ',url)
        let  response = ''
        //console.log('Request : ', json_withdrawal_request)
        // url = '';
       let result200 = await fetch(url, {
                headers: {
                    'Accept': 'application/json',
                },
                method: "POST",
                body: JSON.stringify(data.toString)
            }) .then((response: any) => response.text())
            .then((text: any) => {
                try {
                  const data = JSON.parse(text);
                    console.log('data',data)
                    socket.write(Buffer.from(text))
                   // response  = data['output_ResponseCode']
                    // if (data['output_ResponseCode'] == '0') {
  
                    //     console.log("Transaction result:", data['output_ResponseDesc'])
                    //     const iso20022 = {
                    //         "code": "3000",
                    //         "message": "Success"
                    //     }
                    //     socket.write(Buffer.from(js2xmlparser.parse("response", iso20022)))
                    
                    // } else if (data['output_ResponseCode'] == '-1') {
  
                    //     console.log("Transaction result:", data['output_ResponseDesc'])
                    //     const iso20022 = {
                    //         "code": "xxxx",
                    //         "message": "Failure"
                    //     }
                    //     socket.write(Buffer.from(js2xmlparser.parse("response", iso20022)))
                    // } else if (data['output_ResponseCode'] == '-3') {
  
                    //     console.log("Transaction result:", data['output_ResponseDesc'])
                    //     const iso20022 = {
                    //         "code": "4000",
                    //         "message": "Duplicate"
                    //     }
                    //     socket.write(Buffer.from(js2xmlparser.parse("response", iso20022)))
                    // }
                    
                } 
                catch (error) {
                    //this._logger.error(error)
                }
              })
             /* const query =  await this._knex('transactiontable').where({id: result}).first().update('reversed', '01').update('success',response)
                    const isoMessage1 =  await this._knex('transactiontable').where({ id: result }).first()
                    table = ''
                    for (var i = 0; i < database.length ; i++) 
                      table = table + pads(`${isoMessage1[`${database[i]}`]}`,spacing[i],' ');
                      
                      log.info(table)
                    console.log('Reflected in database')*/
                    
        }else if(mti =='0100'){
          flag = '0100'
              const legacyMessage = this._decode(data) 
              var lpsKey = null
              var messageType = null
              legacyMessage[0] = mti
              lpsKey = this.getLpsKey(legacyMessage)
              let c = legacyMessage[28]
              let a = c.split('D');
              // let phoneNo = isoUnpacked[2].substr(0, 12);
              let phoneNo = legacyMessage[102]
              const surcharge = a[1];
              let uuid = guid1(legacyMessage[11]);
              let quoteAmount = null
              let acquirerfee = null
              let  payeefspfee = null
             
              let quote_request = {

                "quoteId": "7c23e80c-d078-4077-8263-2c047876fcf6",
                "transactionId": uuid,
                "payee": {
                    "partyIdInfo": {
                        "partyIdType": "IBAN",
                        "partyIdentifier": "PTID1245",
                        "fspId": "payerfsp"
                    }
                },
                "payer": {
                    "personalInfo": {
                        "complexName": {
                            "firstName": "Mats",
                            "lastName": "Hagman"
                        }
                    },
    
                    "partyIdInfo": {
                        "partyIdType": "MSISDN",
                        "partyIdentifier": phoneNo,
                        "fspId": "BankNrOne"
                    }
    
                },
                "amountType": "RECEIVE",
                "surcharge": '',
                "amount": {
                    "amount": legacyMessage[4]/100,
                    "currency": legacyMessage[49]
                },
                "transactionType": {
                    "scenario": "TRANSFER",
                    "initiator": "PAYER",
                    "initiatorType": "CONSUMER"
                },
                "note": "From Mats",
                "expiration": new Date(new Date().getTime() + 10000)
            }
              quote_request.surcharge = surcharge;
              // console.log("The OpenAPI Quote Request to PayeeFSP")
              // console.log("-------------------------------------")
              // console.log(quote_request)

              const checkPayerUrl = `${checkParticipantEndpoint}/${phoneNo}`;
              console.log('Received ISO-0100  message : ',legacyMessage)
              console.log("SENDING TO ALS FOR CHECKING PARTICIPANT WITH PARTYID." + phoneNo)
                  ///console.log(phoneNo)
              console.log(checkPayerUrl)
               await fetch(checkPayerUrl, {
                      method: 'GET'
                  })
                  .then((response:any) => response.text())    
                  .then((text:any) => {
                      try {
                          const data = JSON.parse(text);
                          console.log("RESPONSE FROM ALS...")
                          console.log(data)
                          console.log('PARTICIPANT EXIST..');
                          console.log("The OpenAPI Quote Request to PayeeFSP")
                          console.log("-------------------------------------")
                          console.log(quote_request)

                          return fetch(quotesEndpoint, {
                                  headers: {
                                      'Accept': 'application/vnd.interoperability.quotes+json;version=1',
                                      'Content-Type': 'application/vnd.interoperability.quotes+json;version=1.0',
                                      'FSPIOP-Source': 'atm',
                                      'FSPIOP-Destination': 'payeefsp',
                                      'Date': new Date().toISOString()
                                  },
                                  method: "POST",
                                  body: JSON.stringify(quote_request)

                              })
                              .then((res:any) => res.json())
                              .then((res:any) => {

                                  quoteAmount = res.quoteAmount.amount;
                                  console.log('quoteAmount',quoteAmount)
                                  acquirerfee = res.payeeReceiveAmount.acquirerfee;
                                  console.log('acquirerfee',acquirerfee)
                                  payeefspfee = res.payeeReceiveAmount.payeefspfee;
                                  console.log('payeefspfee',payeefspfee)
                                  payeefspfee = Number(payeefspfee) * 100
                                  payeefspfee = payeefspfee.toString();
                                  payeefspfee = payeefspfee

                                  console.log('payeefspfee :',payeefspfee)
                                  

                                  console.log(res.quoteAmount)
                                 // console.log(legacyMessage)
                                  // console.log('isoUnpacked after receiving quotes----------------');
                                 // console.log(legacyMessage[0])
                                  if (legacyMessage[0] == '0100') {
                                      //let isoUnpackedCopy = legacyMessage;
                                      legacyMessage[0] = '0110';
                                      legacyMessage[30] = 'D00000' + payeefspfee;
                                      legacyMessage[39] = '00';
                                      let quotenoSend = pad(+quoteAmount * 100, 7)
                                      legacyMessage[48] = quoteAmount.toString();
                                      //isoUnpackedCopy[48] = Math.floor(quoteAmount).toString();
                                      socket.write(encode({ ...legacyMessage, 0: '0110', 39: '00' }))
                                      this._logger.info('Sending reponse:')
                                     
                                      console.log(legacyMessage)

                                  }

                              })
                      } catch (err) {
                          console.log('invalid json')
                          console.log(err);

                          legacyMessage[0] = '0110';
                          legacyMessage[39] = '56';

                          console.log('sending 0110 message with resp code 56')
                          socket.write(encode({ ...legacyMessage, 0: '0110', 39: '56' }))
                      }
                  })
        }else if(mti == '0200'){
            
            const legacyMessage = this._decode(data) 
              var lpsKey = null
              var messageType = null
              legacyMessage[0] = mti
              lpsKey = this.getLpsKey(legacyMessage)
              console.log('Recieved')
              console.log(legacyMessage)

            if (legacyMessage[0] == '0200' && legacyMessage[3] == '010000' || '000000') {
              //let isoUnpackedCopy = legacyMessage;
              legacyMessage[0] = '0210';
              legacyMessage[39] = '00';
              let phoneNo =  legacyMessage[102]
              const otp_request = {
                  "phoneNo": legacyMessage[102],
                  "otp": legacyMessage[103]
              }
              let uuid = guid1(legacyMessage[11]);
              let transaction_request = {
                "quoteId": "7c23e80c-d078-4077-8263-2c047876fcf6",
                "transactionId": uuid,
                "payee": {
                    "partyIdInfo": {
                        "partyIdType": "IBAN",
                        "partyIdentifier": legacyMessage[41],
                        "fspId": "payerfsp"
                    }
                },
                "payer": {
                    "personalInfo": {
                        "complexName": {
                            "firstName": "Mats",
                            "lastName": "Hagman"
                        }
                    },
                    "partyIdInfo": {
                        "partyIdType": "MSISDN",
                        "partyIdentifier": phoneNo,
                        "fspId": "BankNrOne"
                    }
                },
                "amountType": "RECEIVE",
                "surcharge": '',
                "amount": {
                    "amount": legacyMessage[4],
                    "currency": legacyMessage[49]
                },
                "transactionType": {
                    "scenario": "TRANSFER",
                    "initiator": "PAYER",
                    "initiatorType": "CONSUMER"
                },
                "note": "From Mats",
                "expiration": new Date(new Date().getTime() + 10000)
            }
              console.log("Converting to open api" +JSON.stringify(transaction_request))
              console.log("Sending to otp verification to " + otpendpoint)
              console.log(otp_request)
              return fetch(otpEndpoint, {
                      headers: {
                          'Accept': 'application/json',
                          'Content-Type': 'application/json'
                      },
                      method: "POST",
                      body: JSON.stringify(otp_request)
                  })
                  .then((res:any)=> res.json())
                  .then((res:any) => {
                    console.log(res)
                      if (res.status == '0') {
                          console.log('otp verified')

                          //transfer req
                          const TransactionUrl = `${TransfersEndpoint}/${phoneNo}`
                          console.log('Sending Transaction request to ' + TransactionUrl)

                          fetch(TransactionUrl, {
                                  headers: {
                                      'Accept': 'application/json',
                                      'Content-Type': 'application/json'
                                  },
                                  method: "PUT",
                                  body: JSON.stringify(transaction_request)
                              })
                              .then((res:any) => {
                                  console.log(res)
                                  if (res.status == 200) {

                                      //isoUnpackedCopy[0] = '0210';
                                      
                                      console.log('Sending reponse----------------');
                                      legacyMessage[0]='0210'
                                      legacyMessage[39]='00'
                                     
                                      socket.write(encode( legacyMessage ))
                                      console.log(legacyMessage)

                                  }
                              })
                       //this._knex.destroy()
     }else{
                        console.log('Invalid OTP or MSISDN')
                        console.log('Sending reponse----------------');
                                      legacyMessage[0]='0210'
                                      legacyMessage[39]='56'
                                     
                                      socket.write(encode( legacyMessage ))
                                      console.log(legacyMessage)

                      }
                  })
          }
        }else if(mti == '1200'){
        
  const testdata = data.slice(2, data.length)
  const header =data.slice(0, 21)
  const MTI = data.slice(21, 23)
  const msg_type = '' + bcd.decode(MTI)
  const headerdata = '' + header
  if (headerdata === 'ISO8583-1993021000000' && msg_type == '1200') {
    const MTI = data.slice(21, 23)
    const Field1 = data.slice(23, 39)
    const Field2 = data.slice(40, 48)
    const f2copy = data.slice(39, 48)
    const bb = bcd.decode(Field2)
    const Field3 = data.slice(48, 51)
    let processing_code = '' + bcd.decode(Field3)
    const length = processing_code.length
    if (length < 6) {
      processing_code = '0' + processing_code
    } else {
      processing_code = '' + bcd.decode(Field3)
    }
    const len = Field3.toString()
    const Field4 = data.slice(51, 57)
    const Field7 = data.slice(57, 62)
    const Field11 = data.slice(62, 65)
    const Field12 = data.slice(65, 71)
    const Field17 = data.slice(71, 73)
    const Field19 = data.slice(73, 75)
    const Field22 = data.slice(75, 87)
    const Field24 = data.slice(87, 89)
    const Field26 = data.slice(89, 91)
    const Field32 = data.slice(92, 95)
    const f32copy = data.slice(91, 95)
    const Field37 = data.slice(95, 107)
    const Field49 = data.slice(107, 109)
    const Field102 = data.slice(110, 129)
    const f102copy = data.slice(109, 129)
    const Field103 = data.slice(data.length - 16, data.length)
    const f103copy = data.slice(129, data.length)
    /***
     * iso 1993 1200.....
     */
    const ISOdata = {
      0: '' + bcd.decode(MTI),
      2: '000' + bcd.decode(Field2),
      3: processing_code,
      4: '00000' + bcd.decode(Field4),
      7: '0' + bcd.decode(Field7),
      11: '00' + bcd.decode(Field11),
      12: '' + bcd.decode(Field12),
      17: '0' + bcd.decode(Field17),
      19: '' + bcd.decode(Field19),
      22: Field22.toString(),
      24: '' + bcd.decode(Field24),
      26: '' + bcd.decode(Field26),
      32: '000' + bcd.decode(Field32),
      37: Field37.toString(),
      49: '' + bcd.decode(Field49),
      102: Field102.toString(),
      103: Field103.toString()
    }
    const customFormats = {
      2: {
        ContentType: 'n',
        Label: 'Time, local transaction (hhmmss)',
        LenType: 'llvar',
        MaxLen: 19
      },

      4: {
        ContentType: 'n',
        Label: 'Amount, transaction',
        LenType: 'llvar',
        MaxLen: 12
      },

      12: {
        ContentType: 'n',
        Label: 'Time, local transaction (hhmmss)',
        LenType: 'fixed',
        MaxLen: 12
      },

      22: {
        ContentType: 'an',
        Label: 'Point Of Service Data Code',
        LenType: 'fixed',
        MaxLen: 12
      },

      26: {
        ContentType: 'n',
        Label: 'Card Acceptor Business Type',
        LenType: 'fixed',
        MaxLen: 4
      },
      49: {
        ContentType: 'n',
        Label: 'Currency Code, Transaction',
        LenType: 'llvar',
        MaxLen: 4
      }
    }

    const isopack2 = new iso8583(ISOdata, customFormats)
    console.log('ISOdata')
    console.log(isopack2)

    const F2Value = '' + bcd.decode(Field2)
    // let phoneNo = F2Value.substring(F2Value.length-10,F2Value.length)
    const phoneNo = '27660119644'
    console.log('phoneNo :' + phoneNo)
    let stan = '' + bcd.decode(Field11)
    if (stan.length == 4) {
      stan = '00' + bcd.decode(Field11)
    }
    if (stan.length == 5) {
      stan = '0' + bcd.decode(Field11)
    }
    const currency = '' + bcd.decode(Field49)
    let F049 = ''
    if (currency === '356') {
      F049 = 'INR'
    } else if (currency === '840') {
      F049 = 'USD'
    } else if (currency === '710') {
      F049 = 'ZAR'
    } else if (currency === '967') {
      F049 = 'ZMW'
    }

    const uuid = guid1(stan)
    const amtIso = (bcd.decode(Field4) / 100).toFixed(2)
    const amtStr = amtIso.toString()

    const quote_request = {
      quoteId: '7c23e80c-d078-4077-8263-2c047876fcf6',
      transactionId: uuid,
      payee: {
        partyIdInfo: {
          partyIdType: 'IBAN',
          partyIdentifier: 'PTID1245',
          fspId: 'payerfsp'
        }
      },
      payer: {
        personalInfo: {
          complexName: {
            firstName: 'Mats',
            lastName: 'Hagman'
          }
        },

        partyIdInfo: {
          partyIdType: 'MSISDN',
          partyIdentifier: phoneNo,
          fspId: 'BankNrOne'
        }
      },
      amountType: 'RECEIVE',
      surcharge: 1,
      amount: {
        amount: amtStr,
        currency: F049
      },
      transactionType: {
        scenario: 'TRANSFER',
        initiator: 'PAYER',
        initiatorType: 'CONSUMER'
      },
      note: 'From Mats',
      expiration: new Date(new Date().getTime() + 10000)
    }

    const surcharge = 1
    quote_request.surcharge = surcharge

    const checkPayerUrl = `${checkParticipantEndpoint}/${phoneNo}`
    console.log(
      'SENDING TO ALS FOR CHECKING PARTICIPANT WITH PARTYID.' + phoneNo
    )
    /// console.log(phoneNo)
    console.log(checkPayerUrl)

    return fetch(checkPayerUrl, {
      method: 'GET'
    })
      .then((response: any) => response.text())
      .then((text: any) => {
        try {
          const data = JSON.parse(text)
          // console.log(data)
          // console.log('valid json')
          console.log('RESPONSE FROM ALS...')
          console.log(data)
          console.log('PARTICIPANT EXIST..')
          console.log('The OpenAPI Quote Request to PayeeFSP')
          console.log('-------------------------------------')
          console.log(quote_request)
          return fetch(quotesEndpoint, {
            headers: {
              Accept: 'application/vnd.interoperability.quotes+json;version=1',
              'Content-Type':
                'application/vnd.interoperability.quotes+json;version=1.0',
              'FSPIOP-Source': 'atm',
              'FSPIOP-Destination': 'payeefsp',
              Date: new Date().toISOString()
            },
            method: 'POST',
            body: JSON.stringify(quote_request)
          })
            .then((res: any) => res.json())
            .then((res: any) => {
              const quoteAmount = res.quoteAmount.amount
              const acquirerfee = res.payeeReceiveAmount.acquirerfee
              let payeefspfee = res.payeeReceiveAmount.payeefspfee
              payeefspfee = Number(payeefspfee) * 100
              payeefspfee = payeefspfee.toString()
              console.log('payeefspfee :')
              console.log(payeefspfee)
              // console.log('res.quoteAmount')
              // console.log(res.quoteAmount)
              // console.log(res.quoteAmount.amount)
              let amount = res.quoteAmount.amount
              amount = amount * 100
              const Quote_amt_buf = Buffer.from([
                0x00,
                0x07,
                0xa0,
                0x02,
                0x04,
                0x01,
                0x01,
                0x01,
                0x00
              ])

              //  console.log('Quote_amt_buf')
              //  console.log(Quote_amt_buf)

              const Quote_amt_buf1 = Buffer.from([0x01, 0x01, 0x01, 0x00])
              //  console.log('amount')
              //  console.log(bcd.decode(Quote_amt_buf1))

              //  console.log(res.quoteAmount.currency)
              // QuoteRes
              const Quote_res = Buffer.from([
                0x49,
                0x53,
                0x4f,
                0x38,
                0x35,
                0x38,
                0x33,
                0x2d,
                0x31,
                0x39,
                0x39,
                0x33,
                0x30,
                0x32,
                0x31,
                0x30,
                0x30,
                0x30,
                0x30,
                0x30,
                0x30,
                0x12,
                0x10,
                0xf6,
                0x70,
                0xa0,
                0x11,
                0x0a,
                0x01,
                0xa0,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x16,
                0x00,
                0x00,
                0x00,
                0x10,
                0x00,
                0x02,
                0x02,
                0x09,
                0x75,
                0x82,
                0x68,
                0x72,
                0x40,
                0x10,
                0x00,
                0x00,
                0x00,
                0x01,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x01,
                0x00,
                0x00,
                0x00,
                0x08,
                0x21,
                0x07,
                0x48,
                0x22,
                0x00,
                0x00,
                0x00,
                0x01,
                0x00,
                0x18,
                0x70,
                0x19,
                0x08,
                0x21,
                0x09,
                0x48,
                0x22,
                0x08,
                0x21,
                0x08,
                0x94,
                0x19,
                0x08,
                0x21,
                0x06,
                0x00,
                0x02,
                0x04,
                0x39,
                0x32,
                0x33,
                0x33,
                0x30,
                0x39,
                0x30,
                0x30,
                0x31,
                0x38,
                0x37,
                0x30,
                0x00,
                0x00,
                0x00,
                0x04,
                0xa0,
                0x02,
                0x01,
                0x70,
                0x09,
                0x67,
                0x09,
                0x99,
                0x06,
                0x00,
                0x02,
                0x02,
                0x13,
                0x30,
                0x30,
                0x30,
                0x32,
                0x30,
                0x34,
                0x31,
                0x38,
                0x30,
                0x32,
                0x36,
                0x38,
                0x37,
                0x30,
                0x32,
                0x38,
                0x30,
                0x30,
                0x31,
                0x10,
                0x30,
                0x30,
                0x30,
                0x32,
                0x30,
                0x32,
                0x30,
                0x39,
                0x37,
                0x35,
                0x38,
                0x32,
                0x36,
                0x38,
                0x37,
                0x32
              ])

              //* ****************************************** Quote res handling*/

              console.log('Quote_res')
              console.log(Quote_res)
              const header = Quote_res.slice(0, 21)
              const headers = Quote_res.slice(0, 21)
              const headerdata = '' + header
              if (headerdata == 'ISO8583-1993021000000') {
                const MTI = Quote_res.slice(21, 23)
                const Field1 = Quote_res.slice(23, 39)
                const Field2 = Quote_res.slice(40, 48)
                const f2copy = Quote_res.slice(39, 48)
                const bb = bcd.decode(Field2)
                const Field3 = Quote_res.slice(48, 51)
                let processing_code = '' + bcd.decode(Field3)
                const length = processing_code.length
                if (length < 6) {
                  processing_code = '0' + processing_code
                } else {
                  processing_code = '' + bcd.decode(Field3)
                }
                const len = Field3.toString()
                // console.log(len.length);
                const Field4 = Quote_res.slice(51, 57)
                // console.log(Field4)
                // console.log('Field4')
                // console.log(bcd.decode(Field4))
                const Field6 = Quote_res.slice(57, 63)
                // console.log('Field6')
                // console.log(bcd.decode(Field6))

                const Field7 = Quote_res.slice(63, 68)
                // console.log(Field7)
                // console.log('Field7')
                // console.log(bcd.decode(Field7))
                const Field10 = Quote_res.slice(68, 72)
                const Field11 = Quote_res.slice(72, 75)
                //   console.log(Field11)
                //   console.log('Field11')
                //   console.log(bcd.decode(Field11))
                const Field12 = Quote_res.slice(75, 81)
                //   console.log(Field12)
                //   console.log('Field12')
                //   console.log(bcd.decode(Field12))
                const Field17 = Quote_res.slice(81, 83)
                //   console.log(Field17)
                //   console.log('Field17')
                //   console.log(bcd.decode(Field17))
                const Field19 = Quote_res.slice(83, 85)
                //   console.log(Field19)
                //   console.log('Field19')
                //   console.log(bcd.decode(Field19))
                const Field28 = Quote_res.slice(85, 88)
                const Field32 = Quote_res.slice(89, 92)
                const f32copy = Quote_res.slice(88, 92)
                const Field37 = Quote_res.slice(92, 104)
                const Field39 = Buffer.from([0x00, 0x00])
                const Field39res = '000'
                const Field48copy = Quote_res.slice(107, 112)
                const Field48 = Quote_res.slice(108, 112)
                const Field49 = Quote_res.slice(112, 114)
                const Field51 = Quote_res.slice(114, 116)
                const Field100copy = Quote_res.slice(116, 120)
                const Field100 = Quote_res.slice(117, 120)
                const Field102 = Quote_res.slice(121, 140)
                const f102copy = Quote_res.slice(120, 140)
                const Field103 = Quote_res.slice(
                  Quote_res.length - 16,
                  Quote_res.length
                )
                const f103copy = Quote_res.slice(140, Quote_res.length)
                const init_len = Buffer.from([0x00, 0xa0])
                var Quote_res_buf_arr = [
                  init_len,
                  header,
                  MTI,
                  Field1,
                  f2copy,
                  Field3,
                  Field4,
                  Field6,
                  Field7,
                  Field10,
                  Field11,
                  Field12,
                  Field17,
                  Field19,
                  Field28,
                  f32copy,
                  Field37,
                  Field39,
                  Quote_amt_buf,
                  Field49,
                  Field51,
                  Field100copy,
                  f102copy,
                  f103copy
                ]
                var Quote_res_buf = Buffer.concat(Quote_res_buf_arr)
                const Quote_res_ISOdata = {
                  0: '' + bcd.decode(MTI),
                  2: '000' + bcd.decode(Field2),
                  3: processing_code,
                  4: '00000' + bcd.decode(Field4),
                  6: '00000' + bcd.decode(Field6),
                  7: '0' + bcd.decode(Field7),
                  10: '0000000' + bcd.decode(Field10),
                  11: '00' + bcd.decode(Field11),
                  12: '' + bcd.decode(Field12),
                  17: '0' + bcd.decode(Field17),
                  19: '' + bcd.decode(Field19),
                  28: '' + bcd.decode(Field28),
                  32: '000' + bcd.decode(Field32),
                  37: Field37.toString(),
                  39: Field39res,
                  48: '0' + bcd.decode(Quote_amt_buf1),
                  49: '' + bcd.decode(Field49),
                  51: '' + bcd.decode(Field51),
                  100: '000' + bcd.decode(Field100),
                  102: Field102.toString(),
                  103: Field103.toString()
                }
                const customFormats = {
                  2: {
                    ContentType: 'n',
                    Label: 'Time, local transaction (hhmmss)',
                    LenType: 'llvar',
                    MaxLen: 19
                  },

                  4: {
                    ContentType: 'n',
                    Label: 'Amount, transaction',
                    LenType: 'llvar',
                    MaxLen: 12
                  },

                  12: {
                    ContentType: 'n',
                    Label: 'Time, local transaction (hhmmss)',
                    LenType: 'fixed',
                    MaxLen: 12
                  },

                  22: {
                    ContentType: 'an',
                    Label: 'Point Of Service Data Code',
                    LenType: 'fixed',
                    MaxLen: 12
                  },

                  26: {
                    ContentType: 'n',
                    Label: 'Card Acceptor Business Type',
                    LenType: 'fixed',
                    MaxLen: 4
                  },
                  49: {
                    ContentType: 'n',
                    Label: 'Currency Code, Transaction',
                    LenType: 'llvar',
                    MaxLen: 4
                  }
                }

                //* ***************************************End of Quote res handling */

                const Quote_res_pack = new iso8583(
                  Quote_res_ISOdata,
                  customFormats
                )
                console.log('Quote_res_pack')
                console.log(Quote_res_pack)
                socket.write(Quote_res_buf)
              }
            })
        } catch (err) {
          console.log('invalid json')
          console.log(err)
        }
      })
      .catch((err: any) => console.log(err))
  }
        }
        }catch (error) {
        this._logger.error(`${this._lpsId} relay: Failed to handle iso message.`)
        this._logger.error(error.message)
      }
      
     // this._knex.destroy()
    // console.log( flag,'**')
     if(flag != '0100' ){
      // console.log('inside closing') 
        // if(flag !='xml ' )  {
          this._socket.destroy()
           await this.shutdown()
         //}
      }
    })

    socket.on('error', error => {
      this._logger.error(`${this._lpsId} relay: Error: ` + error.message)
    })
    this._socket = socket
    
   // this._socket.destroy()
    // await this.shutdown()
  }

  async start (): Promise<void> {
    this._authorizationResponseWorker = new Worker(`${this._lpsId}AuthorizationResponses`, async (job: Job<LegacyAuthorizationResponse>) => {
      try {
        await this.handleAuthorizationResponse(job.data)
      } catch (error) {
        this._logger.error(`${this._lpsId} AuthorizationResponse worker: Failed to handle message. ${error.message}`)
      }
    }, { connection: this._redisConnection })

    this._financialResponseWorker = new Worker(`${this._lpsId}FinancialResponses`, async (job: Job<LegacyFinancialResponse>) => {
      try {
        await this.handleFinancialResponse(job.data)
      } catch (error) {
        this._logger.error(`${this._lpsId} FinancialResponse worker: Failed to handle message. ${error.message}`)
      }
    }, { connection: this._redisConnection })

    this._reversalResponseWorker = new Worker(`${this._lpsId}ReversalResponses`, async (job: Job<LegacyReversalResponse>) => {
      try {
        await this.handleReversalResponse(job.data)
      } catch (error) {
        this._logger.error(`${this._lpsId} ReversalResponse worker: Failed to handle message. ${error.message}`)
      }
    }, { connection: this._redisConnection })
  }

  async shutdown (): Promise<void> {
    this._logger.info(this._lpsId + ' relay: shutting down...')
    if (this._server) {
      this._server.close()
    }
    this._logger.debug(this._lpsId + ' relay: shutting down authorizationResponseWorker...')
    if (this._authorizationResponseWorker) {
      await this._authorizationResponseWorker.close()
    }
    this._logger.debug(this._lpsId + ' relay: shutting down financialResponseWorker...')
    if (this._financialResponseWorker) {
      await this._financialResponseWorker.close()
    }
  }

  getLpsKey(legacyMessage: LegacyMessage): string {
    return ''
  }

  async handleAuthorizationResponse (authorizationResponse: LegacyAuthorizationResponse): Promise<void> {
    const message = await this.mapToAuthorizationResponse(authorizationResponse)

    this._socket.write(this._encode(message))
  }

  async handleFinancialResponse (financialResponse: LegacyFinancialResponse): Promise<void> {
    const message = await this.mapToFinancialResponse(financialResponse)

    this._socket.write(this._encode(message))
  }

  async handleReversalResponse (reversalResponse: LegacyReversalResponse): Promise<void> {
    const message = await this.mapToReversalAdviceResponse(reversalResponse)

    this._socket.write(this._encode(message))
  }

  getMessageType (mti: string): LegacyMessageType {
    switch (mti) {
      case '0100':
        return LegacyMessageType.authorizationRequest
       case '0200':
        return LegacyMessageType.financialRequest
      // case '0420':
      //   return LegacyMessageType.reversalRequest
      //   case 'xml ':
      //   return LegacyMessageType.financialRequest
      //   case '0421':
      //   return LegacyMessageType.financialRequest
      default:
        throw new Error(this._lpsId + 'relay: Cannot handle legacy message with mti: ' + mti)
    }
  }

  calculateFee (legacyMessage: LegacyMessage): Money {
    const amount = legacyMessage[28] ? new MlNumber(legacyMessage[28].slice(1)).divide(100).toString() : '0'
    return { amount, currency: this.getMojaloopCurrency(legacyMessage[49]) }
  }

  getMojaloopCurrency (legacyCurrency: string): string {
    return 'USD' // TODO: currency conversion from legacyMessage[49]
  }

  getTransactionType (legacyMessage: LegacyMessage): { initiatorType: 'DEVICE' | 'AGENT'; scenario: 'WITHDRAWAL' | 'REFUND' } {
    switch (legacyMessage[123].slice(-2)) {
      case '01': {
        return {
          initiatorType: 'AGENT',
          scenario: 'WITHDRAWAL'
        }
      }
      case '02': {
        return {
          initiatorType: 'DEVICE',
          scenario: 'WITHDRAWAL'
        }
      }
      default: {
        throw new Error('Legacy authorization request processing code not valid')
      }
    }
  }

  getResponseCode (response: ResponseType): string {
    switch (response) {
      case ResponseType.approved:
        return this._responseCodes.approved
      case ResponseType.invalid:
        return this._responseCodes.invalidTransaction
      case ResponseType.noPayerFound:
        return this._responseCodes.noIssuer
      case ResponseType.payerFSPRejected:
        return this._responseCodes.doNotHonour
      default:
        throw new Error(`${this._lpsId} relay: Cannot map to a response code.`)
    }
  }

  async mapFromAuthorizationRequest (lpsMessageId: string, legacyMessage: LegacyMessage): Promise<LegacyAuthorizationRequest> {
    throw new Error('map from authorization request is a no op for the base tcp relay class')
  }

  async mapToAuthorizationResponse (authorizationResponse: LegacyAuthorizationResponse): Promise<LegacyMessage> {
    throw new Error('map to authorization response is a no op for the base tcp relay class')
  }

  async mapFromFinancialRequest (lpsMessageId: string, legacyMessage: LegacyMessage): Promise<LegacyFinancialRequest> {
    throw new Error('map from financial request is a no op for the base tcp relay class')
  }

  async mapToFinancialResponse (financialResponse: LegacyFinancialResponse): Promise<LegacyMessage> {
    throw new Error('map to financial response is a no op for the base tcp relay class')
  }

  async mapFromReversalAdvice (lpsMessageId: string, legacyMessage: LegacyMessage): Promise<LegacyReversalRequest> {
    throw new Error('map from reversal request is a no op for the base tcp relay class')
  }

  async mapToReversalAdviceResponse (reversalResponse: LegacyReversalResponse): Promise<LegacyMessage> {
    throw new Error('map to reversal response is a no op for the base tcp relay class')
  }
}

const guid = () => {
  function s4() {
      return Math.floor((1 + Math.random()) * 0x10000)
          .toString(16)
          .substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
      s4() + '-' + s4() + s4() + s4();
}

//console.log(guid());

function pad(num:any, size:number) {
  var s = num + "";
  while (s.length < size) s = "0" + s;
  return s;
}

function guid1(stan:any) {
  //console.log(`stan: ${stan}`)

   function g(s:any) {
       var p = (stan.toString(16) + "000000000").substr(2, 8);
       return s ? "-" + p.substr(0, 4) + "-" + p.substr(4, 4) : p;
   }
   return g(false) + g(true) + g(true) + g(false);
 }