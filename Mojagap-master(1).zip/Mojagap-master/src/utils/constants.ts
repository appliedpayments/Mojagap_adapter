export const HOST = 'http://122.165.152.131:8444'
export const databasefile='C:/Users/User/Desktop/databaselog.log'
export const quotesEndpoint = HOST + '/payeefsp/quotes'
export const otpEndpoint = HOST + '/accountlookup/authorizations'
export const otpendpoint = HOST + '/payerfsp/authorizations'
export const checkParticipantEndpoint = HOST + '/accountlookup/correlationid'
export const TransfersEndpoint = HOST + '/payerfsp/transfers'
export const database = new Array('id','msisdn','amount','currencycode','incoming_format','conversion_to','input_BankShortcode','input_ThirdPartyReference','success','reversed','created_at');
export const spacing = new Array(20,20,20,20,20,20,20,27,20,20,20,20)
export var  url = `http://122.165.152.131:8444/payeefsp/callbacks/` 
export const log = null //= require('simple-node-logger').createSimpleFileLogger(databasefile);
export const url_autorization = 'http://122.165.152.131:8445/accountlookup/authorization/'
export const dblogandwriteflag = true
export const url_mpesa =`http://122.165.152.131:8444/payeefsp/callbacks/` 
export const url_openapi =`http://122.165.152.131:8444/payeefsp/callbacks/` 
export const url_20022 = `http://122.165.152.131:8444/payeefsp/callbacks/` 

  
 



 