ALTER USER 'root' IDENTIFIED WITH mysql_native_password BY 'root';
CREATE DATABASE testing;