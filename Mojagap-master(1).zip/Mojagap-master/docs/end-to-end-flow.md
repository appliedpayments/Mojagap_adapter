<img src="../media/authorization-flow.svg" style="background: white"/>
<img src="../media/financial-flow.svg" style="background: white"/>